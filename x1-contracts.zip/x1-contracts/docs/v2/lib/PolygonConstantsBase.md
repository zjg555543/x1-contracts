This contract will contain the constants used across different contracts


