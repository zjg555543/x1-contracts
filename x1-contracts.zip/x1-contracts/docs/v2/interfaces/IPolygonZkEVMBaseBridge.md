


## Functions
### bridgeAsset
```solidity
  function bridgeAsset(
  ) external
```




### bridgeMessage
```solidity
  function bridgeMessage(
  ) external
```




### claimAsset
```solidity
  function claimAsset(
  ) external
```




### claimMessage
```solidity
  function claimMessage(
  ) external
```




### updateGlobalExitRoot
```solidity
  function updateGlobalExitRoot(
  ) external
```




