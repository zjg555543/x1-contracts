


## Functions
### wrappedTokenToTokenInfo
```solidity
  function wrappedTokenToTokenInfo(
  ) external returns (uint32, address)
```




### updateGlobalExitRoot
```solidity
  function updateGlobalExitRoot(
  ) external
```




### activateEmergencyState
```solidity
  function activateEmergencyState(
  ) external
```




### deactivateEmergencyState
```solidity
  function deactivateEmergencyState(
  ) external
```




### bridgeAsset
```solidity
  function bridgeAsset(
  ) external
```




### bridgeMessage
```solidity
  function bridgeMessage(
  ) external
```




### bridgeMessageWETH
```solidity
  function bridgeMessageWETH(
  ) external
```




### claimAsset
```solidity
  function claimAsset(
  ) external
```




### claimMessage
```solidity
  function claimMessage(
  ) external
```




### initialize
```solidity
  function initialize(
  ) external
```




### getTokenMetadata
```solidity
  function getTokenMetadata(
  ) external returns (bytes)
```




