


## Functions
### getLastGlobalExitRoot
```solidity
  function getLastGlobalExitRoot(
  ) external returns (bytes32)
```




### getRoot
```solidity
  function getRoot(
  ) external returns (bytes32)
```




