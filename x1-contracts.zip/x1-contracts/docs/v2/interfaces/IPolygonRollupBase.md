


## Functions
### initialize
```solidity
  function initialize(
  ) external
```




### onVerifyBatches
```solidity
  function onVerifyBatches(
  ) external
```




