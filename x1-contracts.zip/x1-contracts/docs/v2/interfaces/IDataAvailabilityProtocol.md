


## Functions
### getProcotolName
```solidity
  function getProcotolName(
  ) external returns (string)
```




### verifyMessage
```solidity
  function verifyMessage(
  ) external
```




