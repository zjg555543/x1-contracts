
A library that provides the necessary calculations to calculate the global exit root

## Functions
### calculateGlobalExitRoot
```solidity
  function calculateGlobalExitRoot(
  ) internal returns (bytes32)
```




