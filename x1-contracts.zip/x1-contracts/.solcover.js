module.exports = {
  skipFiles: ['mocks/', 'interfaces/'],
  configureYulOptimizer: true,
};