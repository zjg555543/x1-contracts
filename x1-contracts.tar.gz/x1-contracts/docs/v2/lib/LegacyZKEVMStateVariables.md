Since the current contract of PolygonZkEVM will be upgraded to a PolygonRollupManager there's defined
all the legacy public variables in order to not use previous used storage slots
The variables will be used by the RollupManager only for initialize the zkEVM inside the initializer function


