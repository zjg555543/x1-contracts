Since the current contract of PolygonZkEVMGlobalExitRoot will be upgraded to a PolygonZkEVMGlobalExitRootV2, and it will implement
the DepositContractBase, this base is needed to preserve the previous storage slots


