


## Functions
### constructor
```solidity
  function constructor(
  ) public
```




### mint
```solidity
  function mint(
  ) external
```




### burn
```solidity
  function burn(
  ) external
```




### permit
```solidity
  function permit(
  ) external
```




### DOMAIN_SEPARATOR
```solidity
  function DOMAIN_SEPARATOR(
  ) public returns (bytes32)
```

Return the DOMAIN_SEPARATOR.


